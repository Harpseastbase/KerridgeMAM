﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesTaxesMAM
{
    public partial class Form1 : Form
    {
        public double Sales { get; set; }
        public double Total { get; set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            comboItems.Text = "";
            //Lbl1.Visible = false;
            radioImport.Checked = false;
            PriceText.Clear();
            TBoxDisplay.Clear();
            Sales = 0;
            Total = 0;
        }

        private void Form1_Shown(object sender, EventArgs e)
        {

            radioImport.Checked = false;
            //var items = new Products().loadItems();
            ItemsPop(new Products().loadItems());
        }

        private void ItemsPop(string[] obj) {
            foreach(var items in obj)
            {
                comboItems.Items.Add(items);
            }            
        }

        private void comboItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboItems.Text.Length != 0) {
                //Lbl1.Visible = true;
                var prices = new Products().loadPrices();
                //Lbl1.Text = prices[comboItems.SelectedIndex].ToString("F2");
            }
            
        }

        private void btnCapture_Click(object sender, EventArgs e)
        {
            var category = new Products().loadCategory();

            if (PriceText.Text.Length < 5)
            {
                MessageBox.Show(" Please the correct price format of the product");
                return;
            }

            if (comboItems.Text.Length == 0) {
                MessageBox.Show(" Please select product");
                return;
            }

            double newVal = 0;
            double importVal = 0;

            switch (category[comboItems.SelectedIndex])
                {
                    case "Books":
                        if (radioImport.Checked)
                        {
                            importVal = new Products().CalTaxImport(Convert.ToDouble(PriceText.Text));
                            Sales += importVal - Convert.ToDouble(PriceText.Text);
                        } else newVal = Convert.ToDouble(PriceText.Text);

                    break;
                    case "Food":
                        if (radioImport.Checked)
                        {
                            importVal = new Products().CalTaxImport(Convert.ToDouble(PriceText.Text));
                            Sales += importVal - Convert.ToDouble(PriceText.Text);
                        }
                        else newVal = Convert.ToDouble(PriceText.Text);
                    break; 
                    case "Medical":
                        if (radioImport.Checked)
                        {
                            importVal = new Products().CalTaxImport(Convert.ToDouble(PriceText.Text));
                            Sales += importVal - Convert.ToDouble(PriceText.Text);
                        }
                        else newVal = Convert.ToDouble(PriceText.Text);
                    break;

                    default:
                    if (radioImport.Checked)
                    {
                        newVal = new Products().CalTaxExport(Convert.ToDouble(PriceText.Text));
                        importVal = new Products().CalTaxImport(newVal);
                        Sales += importVal - Convert.ToDouble(PriceText.Text);
                    }
                    else {
                        newVal = new Products().CalTaxExport(Convert.ToDouble(PriceText.Text));
                        Sales += newVal - Convert.ToDouble(PriceText.Text);
                    }
                    break;
                }


            if (radioImport.Checked)
            {
                Total += importVal;
                TBoxDisplay.AppendText($"\r\n 1 {comboItems.Text} : {importVal.ToString("F2")}");
            }
            else {
                Total += newVal;
                TBoxDisplay.AppendText($"\r\n 1 {comboItems.Text} : {newVal.ToString("F2")}");
            }
            
        }

        private void btnResults_Click(object sender, EventArgs e)
        {
            TBoxDisplay.AppendText($"\r\n\r\n Sales Taxes: {Sales.ToString("F2")}");
            TBoxDisplay.AppendText($"\r\n\r\n Total: {Total.ToString("F2")}");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            radioImport.Checked = false;
        }
    }
}
