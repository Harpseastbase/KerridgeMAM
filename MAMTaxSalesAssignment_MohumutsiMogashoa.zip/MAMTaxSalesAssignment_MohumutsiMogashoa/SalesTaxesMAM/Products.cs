﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTaxesMAM
{
    public class Products
    {
        string[] products = { "Book", "Music CD", "Chocolate Box", "Chocolate Bar"
                , "Perfume ","Paracetamol"
                ,"Chocolates"};

        string[] category = { "Books", "Entertainment", "Food", "Food"
                , "Deodrant","Medical"
                ,"Food"};

        double[] prices = { 12.49, 14.99, 10.00, 0.85, 47.50,
                27.99, 18.99, 9.75, 11.25 };

        public string[] loadCategory()
        {
            return category;
        }
        public string[] loadItems() {
            return products;
        }
        public double[] loadPrices()
        {
            return prices;
        }

        public double CalTaxExport(double value)
        {
            double Aprice = value * 0.1;
            return Aprice + value;
        }

        public double CalTaxImport(double Bvalue)
        {
            double Bprice = Bvalue * 0.05;
            return Bprice + Bvalue;
        }

    }
}
